
import { useLocation } from "react-router-dom";

export default function ComparisonPage() {
  const { state } = useLocation();
  const { scores } = state;

  const streams = Object.entries(scores);

  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
      {streams.map(([name, score], idx) => (
        <div key={idx} className="p-4 bg-white rounded-xl shadow">
          <h2 className="text-xl font-semibold">{name}</h2>
          <p className="mt-2">Score: {score}</p>
          <p className="mt-2">
            Possible Careers:{" "}
            {name === "Engineering" && "Engineer, Scientist, Developer"}
            {name === "Science" && "Doctor, Researcher, Teacher"}
            {name === "Commerce" && "CA, Analyst, Manager"}
            {name === "Arts" && "Writer, Lawyer, Designer"}
          </p>
        </div>
      ))}
    </div>
  );
}
