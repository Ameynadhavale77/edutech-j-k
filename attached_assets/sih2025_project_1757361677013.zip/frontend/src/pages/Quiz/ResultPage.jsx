
import { useLocation, Link } from "react-router-dom";

export default function ResultPage() {
  const { state } = useLocation();
  const { recommended, alternatives, scores } = state;

  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-bold">🎯 Your Recommended Stream</h1>
      <p className="mt-4 text-xl">{recommended[0]} ({recommended[1]} points)</p>

      <h2 className="mt-6 text-lg font-semibold">Other options:</h2>
      {alternatives.map((s, i) => (
        <p key={i}>{s[0]} ({s[1]} points)</p>
      ))}

      <div className="mt-6">
        <Link to="/comparison" state={{ scores }}
          className="px-4 py-2 bg-blue-500 text-white rounded-lg">
          Compare with Other Streams (Optional)
        </Link>
      </div>
    </div>
  );
}
