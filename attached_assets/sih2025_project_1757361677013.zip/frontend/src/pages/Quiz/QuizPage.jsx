
import { useState } from "react";
import quizData from "../../public/data/quiz_questions_full.json";
import { calculateResult } from "../../src/services/resultSystem";
import { useNavigate } from "react-router-dom";

export default function QuizPage() {
  const [answers, setAnswers] = useState([]);
  const navigate = useNavigate();

  const handleAnswer = (qIndex, oIndex) => {
    const newAns = [...answers];
    newAns[qIndex] = oIndex;
    setAnswers(newAns);
  };

  const handleSubmit = () => {
    const result = calculateResult(answers);
    navigate("/result", { state: result });
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Career Quiz</h1>
      {quizData.questions.map((q, qIndex) => (
        <div key={qIndex} className="mt-4">
          <p>{q.question}</p>
          {q.options.map((opt, oIndex) => (
            <button
              key={oIndex}
              onClick={() => handleAnswer(qIndex, oIndex)}
              className="block px-3 py-1 mt-2 border rounded"
            >
              {opt.text}
            </button>
          ))}
        </div>
      ))}
      <button
        onClick={handleSubmit}
        className="mt-6 px-4 py-2 bg-blue-500 text-white rounded"
      >
        Submit Quiz
      </button>
    </div>
  );
}
