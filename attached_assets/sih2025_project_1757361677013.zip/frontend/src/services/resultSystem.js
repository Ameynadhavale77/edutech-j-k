
import quizData from "../public/data/quiz_questions_full.json";

export function calculateResult(userAnswers) {
  const scores = {};

  userAnswers.forEach((answerIndex, qIndex) => {
    const q = quizData.questions[qIndex];
    const chosen = q.options[answerIndex];

    if (chosen.stream) {
      chosen.stream.forEach(s => {
        scores[s] = (scores[s] || 0) + 1;
      });
    }
  });

  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);

  return {
    scores,
    recommended: sorted[0],
    alternatives: sorted.slice(1, 3)
  };
}
