
import express from "express";
import cors from "cors";
import colleges from "./data/colleges.json" assert { type: "json" };

const app = express();
app.use(cors());

app.get("/api/colleges", (req, res) => {
  res.json(colleges);
});

app.get("/api/colleges/:id", (req, res) => {
  const college = colleges.find(c => c.id === parseInt(req.params.id));
  res.json(college || {});
});

app.listen(4000, () => console.log("Backend running on http://localhost:4000"));
